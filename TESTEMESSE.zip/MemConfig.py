# Parametros de entrada a respeito da memoria

TAM_MEM = 500
TAM_BLOCO = 1



